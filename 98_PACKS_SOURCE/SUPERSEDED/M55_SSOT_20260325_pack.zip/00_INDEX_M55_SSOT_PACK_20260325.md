# M55_SSOT_PACK_20260325

Status: READY-FOR-CURSOR  
Mode: product-law consolidation / single-hero public release / subscription-gated timeline extension  
Purpose: 2026-03-25 時点の current Web truth と次層 monetization law を混線なく固定するための新規SSOTパック

---

## Included files

1. `M55_REPORT_PRODUCT_STRUCTURE_SSOT_v1.md`
2. `M55_REPORT_CONCIERGE_ROOM_SSOT_v1.md`
3. `M55_AI_CONSULT_SAFETY_AND_LIMITS_SSOT_v1.md`
4. `M55_SUBSCRIPTION_GATE_AND_ELIGIBILITY_SSOT_v1.md`
5. `M55_TIMELINE_DTR_REQUIREMENTS_SSOT_v1.md`

---

## Intent

今回のパックは、以下を同時に達成するために作成する。

- current Web public surface を **single hero SKU** のまま固定する
- entry report を静的な「トリセツ」として定義する
- purchaser-only concierge room の権利と上限を固定する
- AI相談の安全・文字数・消費条件を固定する
- 旧 `Personal DTR は全プラン購入可 / サブスクと独立` 条文を、**timeline/history-dependent DTR には適用しない** と明示上書きする
- 将来の moat を `subscription + stored history + timeline reading` に寄せる

---

## Relationship to existing law

### Keep active
- current public truth: `free -> entry report -> purchaser-only concierge room`
- internal canonical key: `dtr`
- public label: `report`
- consult ticket is a report attribute, not a public standalone SKU
- unknown key = fail
- public-safe wording only

### Explicitly supersede in scope
This pack supersedes the older rule that stated:
- `Personal DTR（恒久）- 購入：全プラン購入可 / サブスクと独立`

Supersession is **narrow and scoped**:
- static entry report remains purchasable without subscription
- timeline/history-dependent DTR does **not** remain independent
- timeline/history-dependent DTR requires active subscription and sufficient stored history

---

## Adoption order

1. `M55_REPORT_PRODUCT_STRUCTURE_SSOT_v1.md`
2. `M55_REPORT_CONCIERGE_ROOM_SSOT_v1.md`
3. `M55_AI_CONSULT_SAFETY_AND_LIMITS_SSOT_v1.md`
4. `M55_SUBSCRIPTION_GATE_AND_ELIGIBILITY_SSOT_v1.md`
5. `M55_TIMELINE_DTR_REQUIREMENTS_SSOT_v1.md`

---

## Final command

このパックの目的は、価格表を増やすことではない。  
**public は一本、権利は厳密、上位 moat は timeline/history 側へ閉じ込めること** である。
