# M55_SUBSCRIPTION_GATE_AND_ELIGIBILITY_SSOT_v1

AUTHORITY: PRIMARY CANDIDATE  
Status: READY-FOR-CURSOR  
Priority: HIGHEST  
Scope: subscription-based eligibility / stored-history gate / supersession of old independent Personal DTR clause  
Intent: static entry report と timeline/history-dependent DTR の購入条件を分離し、保存価値を M55 の moat として固定する

---

## 0. Executive judgment

M55 の本命 moat は、単発 report ではなく
- 保存
- 履歴
- 比較
- 時間軸
である。

したがって、すべての DTR を独立販売するのではなく、
- static entry report = independent purchase allowed
- timeline/history-dependent DTR = active subscription + sufficient stored history required
と分離する。

---

## 1. Scope of this SSOT

This SSOT governs:
- who may purchase which DTR family
- when stored history is mandatory
- which older clause is superseded
- what subscription means commercially

This SSOT does not govern:
- public surface layout
- consult room price
- detailed timeline data thresholds

---

## 2. Product family eligibility split

### 2.1 Entry Report
- category: static
- timeline usage: none
- stored history dependency: none
- purchase eligibility: public / non-subscriber allowed
- subscription requirement: none

### 2.2 Timeline / History-dependent DTR
- category: dynamic-or-personal extension using time axis
- timeline usage: required
- stored history dependency: required
- purchase eligibility: subscribers only
- subscription requirement: active Standard or Premium minimum
- public display state: HOLD / not current home hero surface

### 2.3 Deep timeline extensions
Future extension may require stricter gate.

Candidate:
- active Premium required
- longer history window required
- tarot-linked / comparative / long-range reading required

This is not current public truth.  
Do not surface this in current build without a later appendix.

---

## 3. Meaning of subscription

Subscription does **not** mean:
- better truth
- stronger destiny
- more accurate fortune
- different calculation engine

Subscription means:
- saved history
- revisitability
- timeline eligibility
- comparative reading eligibility
- accumulated observation structure

---

## 4. Stored history as eligibility rail

### 4.1 Hard rule
If a DTR requires historySignals or longTermWindow,
purchase is not allowed unless:
- user has active eligible subscription
- minimum stored history requirement is satisfied

### 4.2 Why
Reason is not “quality upsell”.  
Reason is **product成立条件**.

Without stored history:
- no valid comparison base
- no timeline continuity
- no accumulated pattern object
- no legitimate time-axis reading

---

## 5. Explicit supersession of old clause

This SSOT explicitly supersedes the following older practical reading:

`Personal DTR（恒久）- 購入：全プラン購入可 / サブスクと独立`

New interpretation:
- this old clause applies only to static entry-style independent report products, if explicitly marked as such
- it does **not** apply to timeline/history-dependent DTR
- timeline/history-dependent DTR is not independent from subscription
- current build must not offer such DTR to non-subscribers

### 5.1 Narrow supersession
This supersession is narrow:
- does not remove already-purchased ownership permanence
- does not change static entry report public purchase
- only changes eligibility for future timeline/history-dependent DTR family

---

## 6. Standard / Premium gate baseline

### 6.1 Standard baseline
Standard can serve as minimum eligibility rail because it provides:
- 30-day retention
- recurring stored observations
- enough data for short-window pattern reading

### 6.2 Premium baseline
Premium serves as expanded rail because it provides:
- 90-day retention
- deeper stored observation base
- longer comparison window
- future tarot-linked / deeper timeline extensions

### 6.3 Public implementation note
Current Web public surface does not have to show Standard / Premium purchase CTAs yet.
This gate may remain internal law until next monetization layer is surfaced.

---

## 7. Forbidden implementations

- offering history-dependent DTR to anonymous / unsubscribed users
- saying subscription changes the result quality
- showing timeline DTR as public hero SKU in current release
- reviving old multi-surface subscription shell in current Web build
- inferring eligibility from vague keys instead of canonical Layer1 facts

---

## 8. Required Layer1 facts

Eligibility evaluation must use canonical facts only.

Minimum:
- `purchase_entitlement_state`
- `retention_window_days`
- `dtr_ownership_type`
- `purchase_surface`
- `purchase_product_code`

Recommended future additions via policy/config:
- `subscription_state`
- `subscription_tier`
- `history_window_days_actual`
- `history_points_count`

Until such fields are formally added, do not guess.  
Fail closed.

---

## 9. Relationship to business model

Public cash engine:
- ¥1,000 static entry report

Retention / moat engine:
- subscription for save / revisit / history

Next monetization layer:
- ¥1,000 timeline/history-dependent DTR gated by subscription + stored history

Thus M55 is not merely “selling reports”.  
M55 is selling **accumulated meaning and time-axis readability**.

---

## 10. Final command

旧「全DTR独立販売」解釈はここで止める。  
**独立販売できるのは静的な入口レポートのみ。  
時間軸DTRは、subscription と stored history が成立条件である。**
