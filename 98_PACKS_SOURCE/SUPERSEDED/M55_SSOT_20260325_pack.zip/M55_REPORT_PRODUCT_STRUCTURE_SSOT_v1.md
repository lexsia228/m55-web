# M55_REPORT_PRODUCT_STRUCTURE_SSOT_v1

AUTHORITY: PRIMARY CANDIDATE  
Status: READY-FOR-CURSOR  
Priority: HIGHEST  
Scope: current report product truth / public label / consult inclusion / future gating note  
Intent: current Web の公開商品 truth と、将来の timeline DTR product family を混線なく固定する

---

## 0. Executive judgment

現時点で current Web の公開商品は増やさない。  
公開面は **single hero SKU** で固定する。

そのうえで、M55 の本命 moat は
- 多層占術ロジック
- 保存された観測
- 過去/未来の時間軸
- 履歴比較
にある。

したがって、
- **public hero SKU** は静的な entry report
- **future moat SKU family** は subscription-gated timeline/history DTR
と分離する。

---

## 1. Current Public Truth

This chapter is current public truth.

### 1.1 Product name
- public label: `リフレクションレポート`
- internal canonical key: `dtr`

### 1.2 Public paid hero SKU
- name: `Entry Report`
- price: `¥1,000`
- access: public purchase allowed
- report type: static
- subscription requirement: none
- stored history requirement: none

### 1.3 Entry Report definition
Entry Report は、初回公開面で販売する唯一の paid SKU である。

役割:
- 無料結果では見えない「自分の取り扱い説明書」を与える
- 時間軸や保存履歴を使わずに成立する
- current Web public surface の唯一の hero SKU として迷いをなくす

### 1.4 Topic definition
Entry Report の初回テーマは固定する。

- product theme: `ユーザーの取り扱い説明書・トリセツ`
- time-axis usage: `none`
- historySignals usage: `none`
- longTermWindow usage: `none`

### 1.5 Output structure
Entry Report は以下を含む。

- structured report body
- 1 / 1 consult included
- teaser + full ownership reader structure
- purchaser-only room access

### 1.6 Recommended report volume
Current internal product target:
- report body target: `2200〜3000 chars`
- consult target: `700〜900 chars`
- total delivered value when consult used: `2900〜3900 chars`

Rule:
- 文字数は product law の一部だが、copy の肥大化競争には使わない
- 価値主語は「自己理解の深さ」と「clarification 可能性」

### 1.7 Consult inclusion
- included consult credits: `1`
- consult credit total at purchase: `1`
- consult is a report attribute
- consult is not a public standalone SKU

### 1.8 Thread ceiling
- max consult per report thread: `3`
- default included: `1`
- top-up maximum additional: `2`

### 1.9 Purchase location
- public purchase lane: allowed for Entry Report
- consult top-up purchase lane: room only
- public home / pricing / report teaser には consult standalone SKU を置かない

---

## 2. Non-Public Next Layer Product Family

This chapter is **not current public truth**.  
This chapter defines the next monetization layer only.

### 2.1 Product family name
- family: `Timeline / History-dependent DTR`
- public copy label candidate: `時間軸レポート` / `変化レポート` / `比較レポート`
- internal canonical key: still `dtr`

### 2.2 Strategic role
Timeline / History-dependent DTR は、M55 の moat を使う本命商品群である。

価値の根拠:
- 複数鑑定レイヤー
- stored history
- 過去/現在/未来の比較
- timeline interpretation
- accumulated observation meaning

### 2.3 Price anchor
Current internal anchor:
- price anchor candidate: `¥1,000`
- public release state: HOLD
- current public display: forbidden

Rule:
- “同価格” は公開面のシンプルさのために使う
- 安売りの物語にしない
- entrance SKU と moat SKU の差は、価格より **成立条件と読みの種類** に置く

### 2.4 Eligibility dependency
Timeline / History-dependent DTR は、以下が成立条件。

- active subscription required
- sufficient stored history required
- required historySignals must exist
- required longTermWindow must exist

### 2.5 Difference from Entry Report
Entry Report との違いの主語は次のとおり。

- report theme
- timeline usage
- history dependency
- comparison depth
- stored history leverage

禁止:
- “高いから深い”
- “支払うと精度が上がる”
- “同じ商品だが上位ほど当たる”

---

## 3. Hard Boundary Rules

### 3.1 Public surface rule
current public surface には、次を出さない。

- subscription price table
- timeline DTR purchase lane
- future report family table
- multi-SKU public price ladder
- standalone consult SKU

### 3.2 No old law revival
次を current build に復活させない。

- old Free / Standard / Premium public surface
- chat-first shell
- Boost public SKU
- app-style commerce tabs

### 3.3 No fake scarcity
禁止:
- 今だけ
- 本日限り
- 残り◯時間
- カウントダウン
- fake urgency

---

## 4. Canonical Key / Label Relation

- internal canonical = `dtr`
- public label = `report`
- Entry Report = current public hero SKU
- Timeline / History-dependent DTR = gated future family
- consult = report attribute
- room = purchaser-only

---

## 5. Commercial meaning

M55 は「DTR を売る会社」ではなく、  
**観測を保存し、意味を積み、時間軸で深く読める会社** として設計する。

したがって、
- public hero SKU は static
- moat SKU は timeline/history
- subscription は保存と資格の rail
である。

---

## 6. Explicit supersession note

This SSOT supersedes the practical interpretation of any older clause that would make all `personal` DTR purchasable independently.

Interpretation after this SSOT:
- `Entry Report` = independent purchase allowed
- `Timeline / History-dependent DTR` = independent purchase not allowed
- old generic reading of `Personal DTR = all plans purchasable` must not drive current build

---

## 7. Final command

public は一本でよい。  
ただし moat は一本にしてはいけない。  
**入口商品は静的、上位商品は履歴依存**。これを唯一の product law とする。
